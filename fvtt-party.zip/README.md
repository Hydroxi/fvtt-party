# fvtt-party
Module for Foundry VTT: Provides an overview about critical stats of PCs in the current world

## Instructions
1. Install the module
2. Activate the module
3. Give your players owner permissions to their tokens, only these will appear in the tracker
4. In the Actor's Tab, there is a new Button on top: 'Party Tracker', clicking on it opens a moveable overview

This module is WIP (Work in Progress)